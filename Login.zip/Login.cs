﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void textBox_user_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void textBox_password_MouseClick(object sender, MouseEventArgs e)
        {
            if (this.textBox_password.Text == "密码")this.textBox_password.Clear();
        }

        private void textBox_user_MouseClick(object sender, MouseEventArgs e)
        {
            if (this.textBox_user.Text == "用户名")
            {
                this.textBox_user.Clear();
            }
            this.textBox_password.PasswordChar = '*';
        }
    }
}
