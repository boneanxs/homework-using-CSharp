﻿namespace Rfid_id
{
    partial class Inquiry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_inquiry = new System.Windows.Forms.Label();
            this.textBox_inquiry = new System.Windows.Forms.TextBox();
            this.textBox_result = new System.Windows.Forms.TextBox();
            this.label_result = new System.Windows.Forms.Label();
            this.btn_inquiry = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_inquiry
            // 
            this.label_inquiry.AutoSize = true;
            this.label_inquiry.Location = new System.Drawing.Point(35, 64);
            this.label_inquiry.Name = "label_inquiry";
            this.label_inquiry.Size = new System.Drawing.Size(119, 12);
            this.label_inquiry.TabIndex = 2;
            this.label_inquiry.Text = "需要查询的标号/编号";
            // 
            // textBox_inquiry
            // 
            this.textBox_inquiry.Location = new System.Drawing.Point(187, 61);
            this.textBox_inquiry.Name = "textBox_inquiry";
            this.textBox_inquiry.Size = new System.Drawing.Size(100, 21);
            this.textBox_inquiry.TabIndex = 3;
            // 
            // textBox_result
            // 
            this.textBox_result.Location = new System.Drawing.Point(187, 207);
            this.textBox_result.Name = "textBox_result";
            this.textBox_result.Size = new System.Drawing.Size(100, 21);
            this.textBox_result.TabIndex = 4;
            // 
            // label_result
            // 
            this.label_result.AutoSize = true;
            this.label_result.Location = new System.Drawing.Point(35, 216);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(119, 12);
            this.label_result.TabIndex = 5;
            this.label_result.Text = "与之对应的编号/标号";
            // 
            // btn_inquiry
            // 
            this.btn_inquiry.Location = new System.Drawing.Point(129, 133);
            this.btn_inquiry.Name = "btn_inquiry";
            this.btn_inquiry.Size = new System.Drawing.Size(75, 23);
            this.btn_inquiry.TabIndex = 6;
            this.btn_inquiry.Text = "查询";
            this.btn_inquiry.UseVisualStyleBackColor = true;
            // 
            // Inquiry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 311);
            this.Controls.Add(this.btn_inquiry);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.textBox_result);
            this.Controls.Add(this.textBox_inquiry);
            this.Controls.Add(this.label_inquiry);
            this.MaximizeBox = false;
            this.Name = "Inquiry";
            this.Text = "查询RFID标签的标号";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_inquiry;
        private System.Windows.Forms.TextBox textBox_inquiry;
        private System.Windows.Forms.TextBox textBox_result;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.Button btn_inquiry;
    }
}