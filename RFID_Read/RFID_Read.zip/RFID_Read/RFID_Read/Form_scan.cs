﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hit.RFID;

namespace HomePage
{
    public partial class Form_scan : Form
    {
        public Form_scan()
        {
            InitializeComponent();
        }

        private void button_scanned_Click(object sender, EventArgs e)
        {
            MessageBox.Show("确定扫描完成并生产入库单");
        }
        //******************ANhui************************************************
        UHFReaderHelper reader = null;
        private void btn_scan_Click(object sender, EventArgs e)
        {
            string goodsID = comboBox_goodsid.Text;
            if(reader == null)
            {
                reader = new UHFReaderHelper();
                reader.Connect();
            }
            if (reader.isConnected == 1)
            {
                goodsID = "M" + goodsID;
                if (reader.WriteEPCData(goodsID))
                    MessageBox.Show("读入成功");
                else
                    MessageBox.Show("请确认卡放置在读卡器上");
            }
            else
                MessageBox.Show("请确认读卡器连接是否成功");
        }
        //******************************Anhui*************************************
    }
}
