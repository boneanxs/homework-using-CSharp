﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModuleTech.Gen2;
using ModuleTech;
using ModuleLibrary;
using System.Timers;
using System.Threading;
using System.Collections;
using System.Text.RegularExpressions;

namespace RFID_Read
{
    public partial class Form1 : Form
    {
        public static readonly string ConAdr = "192.168.1.100";//connect address
        public static readonly int antNum = 4;//antnna count
        public static readonly int genSession = 1;
        public static readonly int readDur = 1000;//read duration
        public bool isGpoSet = false; //set Gpo
        public string accPass = "1";//access password
        public static readonly uint EpcAdr = 2; //Epc read start
        public static readonly byte EpcEnd = 4; //Epc data count
        public Reader rdr;
        public double consumeNum = 0;
        System.Timers.Timer autoAcq = new System.Timers.Timer();
        Mutex tagMutex = new Mutex();
        List<tagInfo> tagList = new List<tagInfo>();
        List<goodInfo> goodList = new List<goodInfo>();
        BindingSource binding_goodList = null;
        UserInfo meb = null;
        Dictionary<string, ArrayList> details_Num = new Dictionary<string, ArrayList>(); 
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rdr = Reader.Create(ConAdr, ModuleTech.Region.NA, (ReaderType)antNum);
            binding_goodList = new System.Windows.Forms.BindingSource { DataSource = goodList };
            Items_Details.DataSource = binding_goodList;
            autoAcq.Interval = 1000;
            autoAcq.Enabled = true;
            autoAcq.Elapsed += new ElapsedEventHandler(autoAcqData_Elapsed);
            autoAcq.AutoReset = true;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void rdrParmSet() // read param set
        {
            if (rdr != null)
            {
                uint PassWord = uint.Parse(accPass, System.Globalization.NumberStyles.AllowHexSpecifier);
                rdr.ParamSet("AccessPassword", PassWord);
                int[] ants = new int[] { 1, 2, 3, 4 };
                SimpleReadPlan searchPlan = new SimpleReadPlan(ants);
                rdr.ParamSet("ReadPlan", searchPlan);

            }
        }
        //*********sql operation******************
        private List<string> getDetailByID(string ID)
        {
            return new List<string>();
        }
        private ArrayList getMemDetailByID(string ID)
        {
            return new ArrayList();
        }
        //*****************************
        // for each tag, discriminate it is member or good, then change details.
        private void updateTagData(TagReadData tag) 
        {
            tagMutex.WaitOne();
            tagList.Add(new tagInfo(tag));
            string EBdData = System.Text.Encoding.Default.GetString(tag.EbdData);
            int isMem = EBdData.IndexOf("m");
            if (isMem == 0)
            {
                ArrayList memDetail = getMemDetailByID(Regex.Replace(EBdData,"^M",""));
                meb = new UserInfo(memDetail);
                ID_Text.Text = meb.ID;
            }
            else
            {
                List<string> goodDetail = getDetailByID(Regex.Replace(EBdData, "^G", ""));
                if (int.Parse(goodDetail[2]) == 1) //check if item is sold
                {
                    if (details_Num.ContainsKey(goodDetail[0]))
                    {
                        ArrayList temp = details_Num[goodDetail[0]];
                        temp[1] = (int)temp[1] + 1;
                        details_Num[goodDetail[0]] = temp;
                    }
                    else
                    {
                        ArrayList temp = new ArrayList();
                        temp[0] = goodDetail[1];
                        temp[1] = 1;
                        details_Num.Add(goodDetail[0], temp);
                    }
                    
                }
            }
            tagMutex.ReleaseMutex();
        }
        private void refreshDataView() // binding source change
        {
            consumeNum = 0;
            foreach (var detail in details_Num)
            {
                ArrayList goodNum = detail.Value;
                goodInfo temp = new goodInfo(detail.Key,(float)goodNum[0],(int)goodNum[1]);
                consumeNum += temp.tPrice;
                binding_goodList.Add(temp);
                Cost_Text.Text = consumeNum.ToString();
            }
        }
        private void autoAcqData_Elapsed(object sender, ElapsedEventArgs e)
        {
            EmbededCmdData ecd = new EmbededCmdData(MemBank.EPC, EpcAdr, EpcEnd);
            rdr.ParamSet("EmbededCmdOfInventory", ecd);
            TagReadData[] tagDatas = rdr.Read(1000);
            if (tagDatas.Length != 0)
            {
                //check here
                if(isGpoSet == false)
                {
                    rdr.GPOSet(1, true);
                    isGpoSet = false;
                }
                //__________________________________________________________
                foreach (TagReadData tag in tagDatas)
                {
                    updateTagData(tag);
                }
                tagMutex.WaitOne();
                refreshDataView();
                tagMutex.ReleaseMutex();
                //modify RFID status 

                //**********************
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
    public class tagInfo
    {
        public tagInfo(string epc, int rcnt, int ant, byte[] emd)
        {
            epcid = epc;
            readcnt = rcnt;
            antid = ant;
            ebdata = emd;
        }
        public tagInfo(TagReadData tag)
        {
            epcid = tag.EPCString;
            readcnt = tag.ReadCount;
            antid = tag.Antenna;
            ebdata = tag.EPC;
        }
        public string epcid;
        public int readcnt;
        public int antid;
        public byte[] ebdata;
    }
    public class goodInfo
    {
        public string name;
        public float uPrice;
        public int num;
        public double tPrice;
        public goodInfo(string name,float uPrice,int num)
        {
            this.name = name;
            this.uPrice = uPrice;
            this.num = num;
            this.tPrice = this.uPrice * this.num;
        }
        public goodInfo()
        {

        }
    }
    public class UserInfo
    {
        public string ID;
        public string name;
        public string number;
        public float balance;
        public UserInfo(ArrayList userDetail)
        {
            this.ID = (string)userDetail[0];
            this.name = (string)userDetail[1];
            this.number = (string)userDetail[2];
            this.balance = (float)userDetail[3];
        }
    }
}
