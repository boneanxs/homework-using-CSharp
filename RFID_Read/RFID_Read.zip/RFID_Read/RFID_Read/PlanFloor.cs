﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Ichnographyn
{
    public partial class PlanFloor : Form
    {

        public PlanFloor()
        {
            InitializeComponent();
        }
        private System.Threading.Thread _th = null; // 开启搜索线程
        private bool isStart = false;//是否开始搜索
        private void PlanFloor_Paint(object sender, PaintEventArgs e)
        {
            //两个购物场所
            Graphics space = e.Graphics;
            Graphics line = e.Graphics;
            space.DrawRectangle(new Pen(Color.Black, 2), 10, 60, 960, 500);
            line.DrawLine(new Pen(Color.Black, 2), 490, 140, 490, 480);
            line.DrawLine(new Pen(Color.Black, 2), 490, 60, 490, 95);
            line.DrawLine(new Pen(Color.Black, 2), 490, 525, 490, 560);
            //货架摆放
            DrawStringRectangleF(e, 100, 140, "货架一");
            DrawStringRectangleF(e, 300, 140, "货架二");
            DrawStringRectangleF(e, 100, 260, "货架三");
            DrawStringRectangleF(e, 300, 260, "货架四");
            DrawStringRectangleF(e, 100, 380, "货架五");
            DrawStringRectangleF(e, 300, 380, "货架六");
            DrawStringRectangleF(e, 580, 140, "货架七");
            DrawStringRectangleF(e, 780, 140, "货架八");
            DrawStringRectangleF(e, 580, 260, "货架九");
            DrawStringRectangleF(e, 780, 260, "货架十");
            DrawStringRectangleF(e, 580, 380, "货架十一");
            DrawStringRectangleF(e, 780, 380, "货架十二");
        }
        public void DrawStringRectangleF(PaintEventArgs e,int x,int y,string s)
        {
            // 显示货架编号
            String drawString = s;
            //字符居中
            StringFormat centerStringFormat = new StringFormat();
            centerStringFormat.Alignment = StringAlignment.Center;
            centerStringFormat.LineAlignment = StringAlignment.Center;
            // 字体、颜色
            Font drawFont = new Font("新宋体", 16);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            // 矩形大小            
            int width = 100;
            int height = 50;
            RectangleF drawRect = new RectangleF(x, y, width, height);
            // 矩形颜色、位置
            Pen blackPen = new Pen(Color.Black);
            e.Graphics.DrawRectangle(blackPen, x, y, width, height);
            e.Graphics.DrawString(drawString, drawFont, drawBrush, drawRect, centerStringFormat);
        }

        private void PlanFloor_Load(object sender, EventArgs e)
        {

        }
        private void ReceiveData()
        {

        }
        private void btn_search_Click(object sender, EventArgs e)
        {
            if (!isStart)
            {
                if (RfID_ID.Text.Trim() != "")
                {
                    isStart = true;
                    _th = new System.Threading.Thread(ReceiveData);
                    _th.Start();
                }
                else
                {
                    MessageBox.Show("请选择RFID标签序号");
                }
            }
            else
            {
                isStart = false;
                _th.Abort();
            }
        }
    }
}
