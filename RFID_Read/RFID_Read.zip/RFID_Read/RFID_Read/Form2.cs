﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace SendMsgSMS
{
    public partial class Form2 : Form
    {
        private string url = "http://utf8.sms.webchinese.cn/?";
        private string strUid = "Uid=anh131";
        private string strKey = "&key=584ee0dc00171571ad3d"; //这里*代表秘钥，由于从长有点麻烦，就不在窗口上输入了
        private string strMob = "&smsMob=";
        private string strContent = "&smsText=【";
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        public string GetHtmlFromUrl(string url)
        {
            string strRet = null;
            if (url == null || url.Trim().ToString() == "")
            {
                return strRet;
            }
            string targeturl = url.Trim().ToString();
            try
            {
                HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(targeturl);
                hr.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";
                hr.Method = "GET";
                hr.Timeout = 30 * 60 * 1000;
                WebResponse hs = hr.GetResponse();
                Stream sr = hs.GetResponseStream();
                StreamReader ser = new StreamReader(sr, Encoding.Default);
                strRet = ser.ReadToEnd();
            }
            catch (Exception ex)
            {
                strRet = null;
            }
            return strRet;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text.ToString().Trim() != "" && textBox2.Text.ToString().Trim() != "" && textBox3.Text.ToString() != null)
            {
                url = url + strUid + strKey + strMob + textBox2.Text + strContent + textBox3.Text +"】";
                string Result = GetHtmlFromUrl(url);

                MessageBox.Show(Result);
            }
        }
    }
}